| `Version` | `Update Notes`                                                        |
|-----------|-----------------------------------------------------------------------|
| 1.0.2     | - Update internal date check.                                         |
| 1.0.1     | - README update. Add credit and thanks where it's due, almost forgot! |
| 1.0.0     | - Initial Release                                                     |